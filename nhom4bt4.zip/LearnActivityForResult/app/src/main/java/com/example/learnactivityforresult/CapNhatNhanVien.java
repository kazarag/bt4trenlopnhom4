package com.example.learnactivityforresult;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class CapNhatNhanVien extends Activity{
    Button btnSubmit;
    EditText txtid, txtname;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_capnhatnhanvien);
        txtid = (EditText) findViewById(R.id.txtempid);
        txtname = (EditText) findViewById(R.id.txtName);
        btnSubmit = (Button) findViewById(R.id.btnBack);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = getIntent();
                Bundle bundle = new Bundle();

                int id = Integer.parseInt(txtid.getText().toString());
                String ten = txtname.getText().toString();
                NhanVien nv = new NhanVien(id,ten);
                bundle.putSerializable("nv",nv);
                intent.putExtras(bundle);
                setResult(MainActivity.SAVE_EDIT_EMPLOYEE,intent);
                finish();
            }
        });

    }

}
