package com.example.learnactivityforresult;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final int NEW_EMPLOYEE = 55;
    public static final int EDIT_EMPLOYEE = 56;
    public static final int SAVE_NEW_EMPLOYEE = 57;
    public static final int SAVE_EDIT_EMPLOYEE = 58;

    ArrayList<NhanVien> arrayList = new ArrayList<NhanVien>();
    ArrayList<PhongBan> ListPhong = new ArrayList<PhongBan>();
    ListView listView;
    int vitrichon = -1;
    ArrayAdapter<NhanVien> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.lvNhanVien);
        arrayList.add(new NhanVien(1, "Nguyễn Văn A"));
        arrayList.add(new NhanVien(2, "Nguyễn Kim D"));
        arrayList.add(new NhanVien(3, "Nguyễn Thị B"));
        arrayList.add(new NhanVien(4, "Nguyễn Văn C"));

        adapter = new ArrayAdapter<NhanVien>(this,android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                vitrichon = position;
                return false;
            }
        });

        registerForContextMenu(listView);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.mnulistviewcontext,menu);
        super.onCreateContextMenu(menu, v, menuInfo);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id== R.id.mnuNew) {
            doNewEmployee();
        }
        else if (id==R.id.mnuUpdate) {
            doEditEmployee();
        }
        else if (id==R.id.mnuDel){
            doDeleteEmplyee();
        }
        return super.onContextItemSelected(item);
    }

    private void doDeleteEmplyee() {
            int id= vitrichon;
            arrayList.remove(id);
        adapter.notifyDataSetChanged();
    }

    private void doEditEmployee() {
        Intent intent = new Intent(this, CapNhatNhanVien.class);
        startActivityForResult(intent,MainActivity.EDIT_EMPLOYEE);
    }

    private void doNewEmployee() {
        Intent intent = new Intent(this, ThemMoiNhanVien.class);
        startActivityForResult(intent,MainActivity.NEW_EMPLOYEE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case MainActivity.NEW_EMPLOYEE:
                if (resultCode == MainActivity.SAVE_NEW_EMPLOYEE)
                {
                    Bundle b = data.getExtras();
                    NhanVien p = (NhanVien) b.getSerializable("nv");
                    arrayList.add(p);
                    adapter.notifyDataSetChanged();
                }
            case MainActivity.EDIT_EMPLOYEE:
                if (resultCode == MainActivity.SAVE_EDIT_EMPLOYEE)
                {
                    Bundle b = data.getExtras();
                    NhanVien p = (NhanVien) b.getSerializable("nv");
                    int temp=-1;
                    for(NhanVien t : arrayList)
                    {
                        temp++;
                        if(t.manv==p.manv)
                            break;
                    }
                    if(temp!=-1)
                    {
                        arrayList.set(temp,p);
                    }
                    adapter.notifyDataSetChanged();
                }
        }

    }
}