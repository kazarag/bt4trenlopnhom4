package com.example.learnactivityforresult;

public class PhongBan {
    int maph;
    public String tenph;
    String mota;

    public PhongBan() {}

    public PhongBan(int maph, String tenph) {
        this.maph = maph;
        this.tenph = tenph;
    }

    public int getMaph() {
        return maph;
    }

    public String getTenph() {
        return tenph;
    }

    public void setMaph(int maph) {
        this.maph = maph;
    }

    public void setTenph(String tenph) {
        this.tenph = tenph;
    }

    @Override
    public String toString() {
        return new String(this.maph + "-" + this.tenph);
    }
}
